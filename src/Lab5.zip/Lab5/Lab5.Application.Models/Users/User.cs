namespace Lab5.Application.Models.Users;

public record User(string Username, string Password, decimal Balance);