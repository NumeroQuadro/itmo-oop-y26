namespace Lab5.Application.Models.Users;

public enum UserType
{
    Admin,
    User,
}