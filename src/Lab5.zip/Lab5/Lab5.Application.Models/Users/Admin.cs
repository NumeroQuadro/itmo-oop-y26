namespace Lab5.Application.Models.Users;

public record Admin(string Username, string Password);