namespace Lab5.Application.Models.Transactions;

public enum TransactionType
{
    Deposit,
    Withdraw,
}